import os

class Rectangle():
    def __init__(self, width, length):
        self.width = width
        self.length = length 
    def get_area(self):

            
        area = self.width * self.length
        return area
    def get_perimeter(self):
        perimeter = 2 * (self.width + self.length)
        return perimeter   
    def vertical_orientation(self): 
        if (self.width > self.length):
            return True 
        else:
            return False 
see = Rectangle(1.1,1.0)
print(see.get_area())
print(see.get_perimeter())
