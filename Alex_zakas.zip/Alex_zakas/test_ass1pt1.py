import unittest

from ass1pt1 import Rectangle

class Test_Rectangle(unittest.TestCase):
    def setUp(self):
        self.see = Rectangle(1.1,1.2)
        self.see1 = Rectangle(1.1,1.0)
    def test_get_area(self):
        self.assertEqual(self.see.get_area(), 1.32)
        
   
    def test_get_perimeter(self):
        self.assertEqual(self.see.get_perimeter(), 4.6)

    def test_vertical_orientation(self):
        self.assertFalse(self.see.vertical_orientation())
        self.assertTrue(self.see1.vertical_orientation())

            
        
if __name__ == "__main__":
    unittest.main()
          